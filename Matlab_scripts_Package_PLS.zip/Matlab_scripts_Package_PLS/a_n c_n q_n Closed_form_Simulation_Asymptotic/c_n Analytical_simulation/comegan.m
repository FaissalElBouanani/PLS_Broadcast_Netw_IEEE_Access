function mo = comegan(gam0bar,alpha,m,omega,n,Me,Kmax)
if n==0
    mo=1;
else
    mo=0;
    for k=1:n
        mo=mo+(k*Me-n+k)*Aomegan(gam0bar,alpha,m,omega,k,Kmax)*comegan(gam0bar,alpha,m,omega,n-k,Me,Kmax);
    end
    mo=mo/n;
end
end
