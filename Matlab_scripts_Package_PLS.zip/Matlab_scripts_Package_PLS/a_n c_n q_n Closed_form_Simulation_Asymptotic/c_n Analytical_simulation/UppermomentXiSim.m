function mo = UppermomentXiSim(gam0Bar,alpha,m,theta,Rs,n,Me)

d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi;
delta=(1-alpha)/alpha;
N=10^7;
PSIij=gamrnd(m,gamEbar/m,Me,N);
Gamij=PSIij./(delta*PSIij+1);
Gami=sum(Gamij,1);
T1= Gami>theta;
T2= Gami(T1);
if sum(T2)>0
mo=sum(T2.^n)/N;
else
    mo=0;
end;
end