function an = AthetanAsy(gam0Bar,alpha,m,theta,n)
 d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi;
delta=(1-alpha)/alpha;
Ptheta=theta*m/(delta*gamEbar*(1-theta));
J0=meijerG([1-n],[],[0],[],theta-1);
J1=meijerG([1-n],[],[1],[],theta-1);
Q=meijerG([1-n,0],[],[0],[m],theta-1);
%theta*m/(delta*gamEbar*(1-theta));
if (theta>=1)
         an=0;
elseif (n==0 && theta<1)
    an=1-Ptheta^m; 
elseif (n==0 && theta==1)
    an=1;
elseif (n>0 && theta==0 )
an=(-1)^n/factorial(n)*(1-gamma(-m)*gamma(n+m)/(factorial(n-1)*gamma(m))*(m/(delta*gamEbar))^m);

elseif (n>0 && theta<1 && m>1 )
    an=(-1)^n/factorial(n)/factorial(n-1)*(J0+J1/(m-1)*Ptheta);
    elseif (n>0 && theta<1 && m<1 )
    an=(-1)^n/factorial(n)/factorial(n-1)*(J0+gamma(-m)/gamma(m)*Q*Ptheta^m);
end
end