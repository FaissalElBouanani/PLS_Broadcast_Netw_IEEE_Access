function qq = qthetanAsy(gam0Bar,alpha,m,theta,Rs,n,Me)
delta=(1-alpha)/alpha;
h1theta=delta*(theta-2^Rs+1)/(Me*2^Rs);
qq=0;
    for k=0:n
    qq=qq+(1-2^Rs)^k/factorial(k)*((2^Rs/delta)^(n-k))*cthetanAsy(gam0Bar,alpha,m,h1theta,n-k,Me);
    end;
end
