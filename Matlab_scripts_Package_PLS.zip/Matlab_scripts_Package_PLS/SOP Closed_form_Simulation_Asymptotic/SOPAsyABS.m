function SOP = SOPAsyABS(gam0Bar,m,Rs,Me,Ml,N)
d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi;
gamDbar=gamEbar;
N*(m*2^Rs)^(m*Ml)
CalligraphA(m,m*Ml,Me)
SOP=N*(m*2^Rs)^(m*Ml)*(CalligraphA(m,m*Ml,Me)+(1-2^(-Rs))*CalligraphA(m,m*Ml,Me)/gamDbar);
end

