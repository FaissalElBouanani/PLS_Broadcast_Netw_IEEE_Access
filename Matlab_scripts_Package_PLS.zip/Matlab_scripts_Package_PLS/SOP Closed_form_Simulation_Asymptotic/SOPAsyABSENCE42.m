function SOP = SOPAsyABSENCE42(gam0Bar,m,Rs,Me,Ml,N,Nmax)
d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi;
gamDbar=gamEbar
qq=0;
for n=m*Ml:Nmax
    qq=qq+nchoosek(n-1,m*Ml-1)*gamma(n+m*Me)/gamma(m*Me)/factorial(n)*(-1)^n*2^(Rs*n)
    %qq=qq+nchoosek(n-1,m*Ml-1)*(m/gamDbar)^n*q0nAsymAbs(gam0Bar,m,Rs,n,Me)
%qq=qq+qn;
end
U1=1-(-1)^(m*Ml)*qq;
SOP=1-U1^N;
end

