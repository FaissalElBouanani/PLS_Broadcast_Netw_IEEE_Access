function SOP = SOPAsy42(gam0Bar,alpha,m,Rs,Me,Ml,N,Kmax)
d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi;
gamDbar=gamEbar
qq=qomegan(gam0Bar,alpha,m,0,Rs,m*Ml,Me,Kmax)
SOP=1-(1-(-m/gamDbar)^(m*Ml)*qq)^N;
end

