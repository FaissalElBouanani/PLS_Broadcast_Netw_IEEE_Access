function pdfz = PDFZi(gam0Bar,alpha,m,Rs,Me,y)
%clear;
%hold on
warning('off','all');%here
mu_1=momZi(gam0Bar,alpha,m,Rs,1,Me);
mu_2=momZi(gam0Bar,alpha,m,Rs,2,Me);
mu_3=momZi(gam0Bar,alpha,m,Rs,3,Me);
mu_4=momZi(gam0Bar,alpha,m,Rs,4,Me);
psi2 = mu_2/mu_1;
psi3 = mu_3/mu_2;
psi4 = mu_4/mu_3;

a3 = (4*psi4 - 9*psi3 + 6*psi2 - mu_1)/(-psi4 + 3*psi3 - 3*psi2 + mu_1)
a2 = (a3/2)*(psi4 - 2*psi3 + psi2) + 2*psi4 -3*psi3 + psi2;
a6 = ((a3*(psi2-mu_1)+2*psi2 - mu_1)/a2) - 3;
a7 = sqrt(((((a3*(psi2-mu_1)+2*psi2 - mu_1)/a2) - 1)^2)-((4/a2)*mu_1*(a3+1)));
a4 = (a6+a7)/2
a5 = (a6-a7)/2
%gammaz(a4+1)*gammaz(a5+1);
a1 = gammaz(a3+1)/(a2*gammaz(a4+1)*gammaz(a5+1))
% for l=1:4
%     mm(l)=a1*a2^(l+1)*gammaz(a4+1+l)*gammaz(a5+1+l)/gamma(a3+1+l)
% end
%here too: between comment operator
W=50;
%pdf_DR(1:length(x)) = a1*meijerG([],[a3],[a4,a5],[], x/a2);

for i=1:length(y)
 % f=@(s) a1*gammaz(a4-a3+s).*gammaz(a5-a3+s)./gammaz(s).*(y(i)/a2).^(-s);
  %cs=max(max(real(-a4+a3),real(-a5+a3)))+.1;
 % pdfz(i) = (y(i)/a2).^(a3)*real(1/(2*pi*1i)*integral(f,cs-W*1i,cs+W*1i))
 pdfz(i)=a1*meijerG([],[a3],[a4,a5],[], y(i)/a2);
end
%plot(y,pdfz,'b');
end