clear;
hold on
alpha=0.25;
y=0.1:.001:.5;
j=1;
ana=PDFZi(10^1.5,alpha,2,0.1,4,y)/1000;
sim0=PDFZiSim(10^1.5,alpha,2,0.1,4,0.1,.5,.001);
for i=1:length(y)
    if mod(i,10)==1
        yy(j)=y(i);
    si(j)=sim0(i);
    j=j+1;
    end
end
plot(y,ana,'b',yy,si,'r*');
 legend('Analytic','Simulation');
 xlabel('$x$');
 ylabel('${f}_{Z_i(x)}$');