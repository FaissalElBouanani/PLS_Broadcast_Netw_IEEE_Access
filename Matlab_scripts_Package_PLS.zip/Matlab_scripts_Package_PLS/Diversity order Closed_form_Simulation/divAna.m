function di = divAna(gamDbar,alpha,m,Rs,Me,Ml,N,Kmax,Nmax)
d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gam0Bar=gamDbar/betaE*d^phi;
SOP=SOPAna42(gam0Bar,alpha,m,Rs,Me,Ml,N,Kmax,Nmax)
di=-log(SOP)/log(gamDbar);
end

