function di = div(gam0Bar,alpha,m,Rs,Me,Ml,N)
d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi;
gamDbar=gamEbar;
10*log10(gamDbar);
delta=(1-alpha)/alpha;
NB=5*10^7;
pp=1;
for i=1:N
PSIij=gamrnd(m,gamEbar/m,Me,NB);
GamEij=PSIij./(delta*PSIij+1);
GamEi=sum(GamEij,1);
Zi=2^Rs*GamEi+2^Rs-1;
gamDij=gamrnd(m,gamDbar/m,Ml,NB);
GamDi=sum(gamDij,1);
Ii=sum(GamDi>Zi)/NB;
pp=pp*Ii;
end;
SOP=1-pp;
di=-log(SOP)/log(gamDbar);
end

