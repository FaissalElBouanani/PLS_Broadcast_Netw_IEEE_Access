function tt=plotDivAna(m,Ml)
hold on;
i=1;j=1;
alpha=.39;
Rs=0;
Me=2;
Kmax=10;
Nmax=10;
N=2;
gamDbar=20:5:100;
for i=1:length(gamDbar)
 diversity(i) = divAna(gamDbar(i),alpha,m,Rs,Me,Ml,N,Kmax,Nmax)
end
semilogy(gamDbar,diversity,'b');
clear;
%  legend('Analytic','Simulation');
%  xlabel('$R_s$');
%  ylabel('SOP');
end
