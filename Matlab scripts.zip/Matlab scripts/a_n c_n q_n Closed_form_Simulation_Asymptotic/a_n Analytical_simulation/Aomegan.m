function an = Aomegan(gam0Bar,alpha,m,omega,n,Kmax)
 d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi;
if alpha==1
    an=gammainc(omega*m/gamEbar,n+m,'upper')*gamma(n+m)/gamma(m)*(-gamEbar/m)^n/factorial(n);
else
delta=(1-alpha)/alpha;
%omega*m/(delta*gamEbar*(1-omega));
if (omega>=1)
         an=0;
elseif (n==0 && omega<1)
    an=gammainc(omega*m/(delta*gamEbar*(1-omega)),m,'upper'); 
elseif (n==0 && omega==1)
    an=1;
elseif (n>0 && omega==0 )
    
ff=@(t) gammaz(t+m).*gammaz(t).*gammaz(-t+n).*(m/(delta*gamEbar)).^(-t);
ct=.1;
    an=(-1)^n/factorial(n)/factorial(n-1)/gamma(m)*real(integral(ff,ct-30*1i,ct+30*1i)/(2*pi*1i));
else

an=0;
for k=0:Kmax
ff=@(t) gammaz(t+m).*gammaz(t)./gammaz(t+k+1).*(m*omega/(delta*gamEbar*(1-omega))).^(-t);
    ct=.1;
    bn=real(integral(ff,ct-10*1i,ct+10*1i)/(2*pi*1i))*(1-omega)^k*factorial(n+k-1);
 
an=an+bn;
end
an=(-1)^n/factorial(n)/factorial(n-1)*an*omega^n/gamma(m);
end
mom=(-1)^n*factorial(n)*an;
end