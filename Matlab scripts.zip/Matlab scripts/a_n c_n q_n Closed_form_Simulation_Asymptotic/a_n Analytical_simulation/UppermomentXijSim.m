function mo = UppermomentXijSim(gam0Bar,alpha,m,theta,n)

d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi;
delta=(1-alpha)/alpha;
N=10^7;
PSIij=gamrnd(m,gamEbar/m,1,N);
Xij=1-1./(delta*PSIij+1);
T1=Xij>theta;
T2=Xij(T1);
%sum(T2)
%T3=T2<1;
if sum(T2)==0
    mo=0;
else
mo=sum(T2.^n)/N;
end
end