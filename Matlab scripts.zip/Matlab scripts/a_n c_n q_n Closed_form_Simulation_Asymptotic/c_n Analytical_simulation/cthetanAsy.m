function mo = cthetanAsy(gam0bar,alpha,m,theta,n,Me)
if n==0
    mo=1;
else
    mo=0;
    for k=1:n
        mo=mo+(k*Me-n+k)*AthetanAsy(gam0bar,alpha,m,theta,k)*cthetanAsy(gam0bar,alpha,m,theta,n-k,Me);
    end
    mo=mo/n;
end;
end
