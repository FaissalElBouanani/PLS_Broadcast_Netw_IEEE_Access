function qq = qomegan(gam0Bar,alpha,m,omega,Rs,n,Me,Kmax)
if (alpha==1)
    delta=1;
else
     delta=(1-alpha)/alpha;
end
% if (alpha==1)
%     htheta=(theta-2^Rs+1)/(Me*2^Rs);
%     delta=1;
% else
%     delta=(1-alpha)/alpha;
% htheta=delta*(theta-2^Rs+1)/(Me*2^Rs);
% end
qq=0;
    for k=0:n
    qq=qq+(1-2^Rs)^k/factorial(k)*((2^Rs/delta)^(n-k))*comegan(gam0Bar,alpha,m,omega,n-k,Me,Kmax);
    end;
  %  mom=(-1)^n*factorial(n)*qq
end
