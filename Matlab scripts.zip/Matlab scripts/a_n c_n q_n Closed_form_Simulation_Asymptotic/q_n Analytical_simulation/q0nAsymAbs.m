function qq = q0nAsymAbs(gam0Bar,m,Rs,n,Me)
d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi
qq=0;
for k=0:n
    qq=qq+(1-2^Rs)^k/factorial(k)*2^(Rs*(n-k))*gamma(n-k+m*Me)/gamma(m*Me)/factorial(n-k)*(-gamEbar/m)^(n-k);
end
    mom=(-1)^n*factorial(n)*qq
end
