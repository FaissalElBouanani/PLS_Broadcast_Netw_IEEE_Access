function SOP = SOPAsy45(gam0Bar,alpha,m,Rs,Me,Ml,N)
d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi;
gamDbar=gamEbar
delta=(1-alpha)/alpha;
% htheta=delta*(theta-2^Rs+1)/(Me*2^Rs);
 SOP=N/factorial(m*Ml)*((m/gamDbar)*(Me*2^Rs/delta+2^Rs-1))^(m*Ml);
%qq=qomegan(gam0Bar,alpha,m,0,Rs,m*Ml,Me,Kmax)
%SOP=1-(1-(-m/gamDbar)^(m*Ml)*qq)^N;
end

