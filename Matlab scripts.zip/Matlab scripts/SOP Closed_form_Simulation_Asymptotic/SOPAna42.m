function SOP = SOPAna42(gam0Bar,alpha,m,Rs,Me,Ml,N,Kmax,Nmax)
d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi;
gamDbar=gamEbar;
delta=(1-alpha)/alpha;
qq=0;
for n=m*Ml:Nmax
qq=qq+nchoosek(n-1,m*Ml-1)*qomegan(gam0Bar,alpha,m,0,Rs,n,Me,Kmax)*(m/gamDbar)^n;
end
SOP=1-(1-(-1)^(m*Ml)*qq)^N;
end

