function mo = c0n(gamEbar,alpha,m,n,Me)
if n==0
    mo=1;
else
    mo=0;
    for k=1:n
        mo=mo+(k*Me-n+k)*A0n(gamEbar,alpha,m,k)*c0n(gamEbar,alpha,m,n-k,Me);
    end
    mo=mo/n;
end;
end
