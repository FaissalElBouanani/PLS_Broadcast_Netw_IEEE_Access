% clear;
% hold on;
% warning('off','all');%here
d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
gamEbar=10^0.2;alpha=0.5;m=2;Me=4;Rs=1;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gam0BAR=gamEbar*d^phi/betaE
%  s=0:0.05:1.05;
%      theta=0:.25:5.25;        
%     for i=1:length(theta)
%         for j=1:length(s)
% sim(i,j)=UMGFZiSim(theta(i),gamEbar,alpha,m,Rs,Me,s(j));
%     end;
% end;
% [Ga,ALP] = meshgrid(s, theta);
%   f1=surf(Ga,ALP,sim);
%   h=gca;
%   set(h,'zscale','log');
% xlabel('s');ylabel('$\theta$');
 %zlabel('$\mathcal{M}_{Z_i(\theta,s)}$');