function qq = momZi(gam0Bar,alpha,m,Rs,n,Me)
delta=(1-alpha)/alpha;
qq=0;
    for k=0:n
    qq=qq+(1-2^Rs)^k/factorial(k)*((2^Rs/delta)^(n-k))*c0n(gam0Bar,alpha,m,n-k,Me);
    end;
    qq=qq*(-1)^n*factorial(n);
end
