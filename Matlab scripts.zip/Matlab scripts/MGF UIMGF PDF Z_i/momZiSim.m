function mo = momZiSim(gam0Bar,alpha,m,Rs,n,Me)
delta=(1-alpha)/alpha;
d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi;
N=10^5;
PSIij=gamrnd(m,gamEbar/m,Me,N);
Gamij=PSIij./(delta*PSIij+1);
Gami=sum(Gamij,1);
%Xi=delta*Gami;
Zi=2^Rs*Gami+2^Rs-1;
mo=mean(Zi.^n);
end