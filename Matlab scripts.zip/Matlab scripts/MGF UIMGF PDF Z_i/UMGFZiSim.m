function mo = UMGFZiSim(theta,gamEbar,alpha,m,Rs,Me,s)
delta=(1-alpha)/alpha;
N=10^5;
PSIij=gamrnd(m,gamEbar,Me,N);
Gamij=PSIij./(delta*PSIij+1);
Gami=sum(Gamij);
Xi=delta*Gami;
Zi=(2^Rs/delta)*Xi+2^Rs-1;
UZi=Zi>=theta;
NewZi=Zi(UZi);
if ~isempty(NewZi)
    mo=mean(exp(-s*NewZi));
else
    mo=0;
end
end

