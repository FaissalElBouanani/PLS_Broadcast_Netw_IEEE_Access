clear;

Nmax=1;
d=10;dref=100;g=10^2.1;lambda=28.6*0.001,phi=2.2;
gamEbar=10^0.5;alpha=0.2;m=1.1;Rs=2;Me=5;
betaE=(g*lambda/4/pi)^2*dref^(phi-2)
gam0BAR=gamEbar*d^phi/betaE
log10(gam0BAR)
i=1
for s=0:0.1:2.5
ana(i)=MGFZiSim(gamEbar,alpha,m,Rs,Me,s);
sim(i)=momZi(gamEbar,alpha,m,Rs,Me,Nmax,s);
i=i+1;
end
s=0:0.1:2.5
semilogy(s,ana,'b',s,sim,'r*');
% legend('Analytic','Simulation');
% xlabel('s');
% ylabel('$\mathcal{M}_{Z_i(s)}$');