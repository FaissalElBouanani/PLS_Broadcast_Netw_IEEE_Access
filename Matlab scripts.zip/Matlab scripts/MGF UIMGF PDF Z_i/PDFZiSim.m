function cpt = PDFZiSim(gam0Bar,alpha,m,Rs,Me,first_value,last_value,step1)
%clear;
delta=(1-alpha)/alpha;
d=10;dref=100;g=10^2.1;lambda=28.6*0.001;phi=2.2;
betaE=(g*lambda/4/pi)^2*dref^(phi-2);
gamEbar=gam0Bar*betaE/d^phi
N=10^7;
g=first_value:step1:last_value;
nn=length(g);
cpt=zeros(1,nn);
PSIij=gamrnd(m,gamEbar/m,Me,N);
Gamij=PSIij./(delta*PSIij+1);
Gami=sum(Gamij,1);
%length(Gami)
%Xi=delta*Gami;
Zi=2^Rs*Gami+2^Rs-1;
%length(Zi)
for i=1:N
    a=Zi(i);
    if (a>=first_value && a<=last_value)
           j=floor((a-first_value)/step1);
           cpt(j+1)=cpt(j+1)+1;
    end
end
%length(cpt)
%sum(cpt)
%pt(nn)=cpt(nn)/N;
 for i=1:nn
 cpt(i)=cpt(i)/N;
 end
% length(cpt)
%sum(cpt)
%plot(g,cpt);
%[p,x] = hist(Zi);
%plot(x,p/sum(p));
%mo=mean(Zi.^n);
end